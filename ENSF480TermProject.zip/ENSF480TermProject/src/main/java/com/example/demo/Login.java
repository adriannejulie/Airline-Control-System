package com.example.demo;

public class Login {
    private String username;
    private String passord;
    
}
